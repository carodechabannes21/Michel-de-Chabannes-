# -*- coding: utf-8 -*-
"""
Created on Fri May  7 15:06:50 2021

@author: Antho
"""

from time import sleep

def get_masques_gel(driver):
    type_list_gel_masques = []
    market_list_gel_masques = []
    masques_gel_name = []
    for element in driver.find_elements_by_class_name('product-availability-label'):
        product = element.text
        masques_gel_name.append(product)
        type_list_gel_masques.append("gel hydroalcoolique")
        market_list_gel_masques.append('Leclerc')
    sleep(5)
    masques_gel_price = []
    for element in driver.find_elements_by_class_name('product-price-wrapper'):
        price = element.text
        masques_gel_price.append(price)
    return market_list_gel_masques, type_list_gel_masques, masques_gel_name, masques_gel_price

def get_name_price_list(driver, nameList):
    product_List=[]
    price_List = []
    market_List = []
    type_List = []
    for name in nameList:
        url = 'https://www.e.leclerc/cat/' + str(name) + '-marque-repere'
        driver.get(url)
        sleep(10)
        for element in driver.find_elements_by_class_name("product-availability-label"):
            product_List.append(element.text)
            type_List.append(name)
            market_List.append("Leclerc")
            sleep(0.1)
        sleep(2)
        for element in driver.find_elements_by_id('price'):
            price_List.append(element.text)
        sleep(5)
        

        if name == 'les-pates' or name == 'legumes-':
            for i in range(2, 4):
                url = 'https://www.e.leclerc/cat/' + str(name) + '-marque-repere?page=' + str(i)
                driver.get(url)
                sleep(10)
                for element in driver.find_elements_by_class_name("product-availability-label"):
                    product_List.append(element.text)
                    type_List.append(name)
                    market_List.append("Leclerc")
                    sleep(0.1)
                sleep(2)
                for element in driver.find_elements_by_id('price'):
                    price_List.append(element.text)
            sleep(5)
            
    return market_List, type_List, product_List, price_List


