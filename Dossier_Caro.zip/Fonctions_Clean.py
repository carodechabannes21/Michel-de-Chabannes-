# -*- coding: utf-8 -*-
"""
Created on Fri May  7 19:32:58 2021

@author: Antho
"""

def clean_masques_gel_name(masques_gel_name):
    del masques_gel_name[-5:]
    product_name = []
    for product in masques_gel_name:
        text_list = product.split("\n")
        nom = text_list[1]
        product_name.append(nom)
    return product_name

def clean_masques_gel_price(masques_gel_price):
    del masques_gel_price[-5:]
    product_price = []
    for price in masques_gel_price:
        p_list = price.replace("\n", '').replace(',','').replace('86.33 € / L (Prix E.Leclerc)','').replace('64.90 € / L (Prix E.Leclerc)','').replace('€','.')
        product_price.append(p_list)
    
    return product_price

def clean_price(price_List):
    new_list_price = []
    for price in price_List:
        p_list = price.replace("\n", '').replace(',', '').replace('€','.')
        new_list_price.append(p_list)
    return new_list_price

def clean_list_name(New_Product_List):
    new_list = []
    for i in New_Product_List:
        text_clean = i.lower().replace('é', 'e').replace('à','a').replace('è', 'e').replace('â', 'a').replace('ï', 'i').replace('ë', 'e').replace('ê','e').replace('î','i')
        new_list.append(text_clean)
    return new_list


def clean_masques_gel(masques_gel_name, masques_gel_price, type_list_gel_masques, market_list_gel_masques):
    
    masques_gel_name = clean_masques_gel_name(masques_gel_name)
    masques_gel_price = clean_masques_gel_price(masques_gel_price)
    del type_list_gel_masques[-5:]
    del market_list_gel_masques[-5:]
    
    return masques_gel_name, masques_gel_price, type_list_gel_masques, market_list_gel_masques

def clean_type_List_All(type_List_All):
    type_List_All[0] = 'masque chirurgical'
    type_List_All[1] = 'masque chirurgical'
    
    new_list = []
    for word in type_List_All:
        text_clean = word.replace('legumes-', 'legumes').replace('-et-levures','').replace('-et-plumeaux','').replace('-', ' ')
        new_list.append(text_clean)
    return new_list

def float_price(New_Price_List):
    New_Price_List = list(map(float, New_Price_List))
    
    return New_Price_List