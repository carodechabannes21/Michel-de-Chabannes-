# -*- coding: utf-8 -*-
"""
Created on Fri May  7 18:37:36 2021

@author: Antho
"""

from time import sleep
from selenium.webdriver.common.keys import Keys
import pandas as pd

def accept_leclerc_terms(driver):
    button_accept = driver.find_element_by_id('onetrust-accept-btn-handler')
    button_accept.click()

def search(driver):
    search = driver.find_element_by_class_name('search-input')
    search.send_keys("Gel hydroalcoolique et masques")
    sleep(5)
    search.send_keys(Keys.ENTER)
    sleep(5)
    search.clear()
    

def dict_to_df(New_Product_List_clean, New_Price_List, market_List_All, type_List_All):
    
    dict1 = {}
    dict1["Market"] = market_List_All
    dict1["Categorie"] = type_List_All
    dict1["Products Name"] = New_Product_List_clean
    dict1["Prices"] = New_Price_List
    
    df = pd.DataFrame.from_dict(dict1)
    
    return df
