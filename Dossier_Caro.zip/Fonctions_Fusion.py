# -*- coding: utf-8 -*-
"""
Created on Sat May  8 00:10:52 2021

@author: Antho
"""


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def mergeCSV(CSV_Carrefour, CSV_Leclerc):
    
   
    
    CSV_Carrefour.drop(['Unnamed: 0'], inplace=True, axis=1)
    CSV_Leclerc.drop(['Unnamed: 0'], inplace=True, axis=1)
    
    fusion = pd.merge(CSV_Carrefour, CSV_Leclerc, on=['Market', 'Categorie', 'Products Name', 'Prices'], how ='outer')
    
    #print(fusion) 
    
    fusion.to_csv('fusion.csv')
    
    return CSV_Carrefour, CSV_Leclerc, fusion
    
    

def RechercheMinimum(fichierCsv,target):
    recherche = fichierCsv.loc[fichierCsv['Categorie'] == target]
    rechercheTrier=recherche.sort_values(by = 'Prices')
    minPrice= rechercheTrier.iloc[0,3]
    #minMarket = rechercheTrier.iloc[0,0]
    
    """#Variable de contrôle 
    print(rechercheTrier)
    print('le minimum est chez : ',minMarket)
    print('le minimum est chez : ',minPrice)
    """
    
    return (minPrice)

#RechercheMinimum(fusion, 'les pates')



def SaisirPanier():
 
    x=0
    tableauProduits=[]
    nameList = ['masque chirurgical','gel hydroalcoolique','legumes', 'farines', 'les pates', 'lingettes', 'papiers toilette', 'laits', 'les riz', 'liquides vaisselles', 'eaux plates', 'huiles']
    print('\n')
    print('Voici les produits disponibles : ', nameList)
    print('\n')
    while x == 0 :
        
        
        print('Pour ajouter un produit, appuyer ESPACE')
        print('Pour quitter appuyer x')
        choix = input('')
        print('\n')
        if choix == ' ':
    
           produit = input('Produit à ajouter au panier : ')
           tableauProduits.append(produit)
           
        elif choix == 'x':
            x += 1
            print('Aurevoir')
        else:
            print('Mauvaise Saisie')
        
        print('Panier :')
        print('========')
        for i in tableauProduits: 
            print('-',i)
        print('\n')
        
    return (tableauProduits)

def Graph(price_list_carrefour, price_list_leclerc, panier):
    
    x = np.arange(len(panier))  # localisation du label 
    width = 0.30  # largeur des barres
    
    fig, ax = plt.subplots()
    rects1 = ax.bar(x - width/2, price_list_leclerc, width, label='Leclerc')
    rects2 = ax.bar(x + width/2, price_list_carrefour, width, label='Carrefour')
    
    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('Prices')
    ax.set_title('Prices Leclerc/Carrefour')
    ax.set_xticks(x)
    ax.set_xticklabels(panier, rotation = 60)
    ax.legend()
    
    ax.bar_label(rects1, padding=3, fontsize = 8.5)
    ax.bar_label(rects2, padding=3, fontsize = 8.5)
    
    plt.show()        
    
def RecherchePanier(fichierLeclerc, fichierCarrefour, panier):
    sommeProduitLeclerc = 0
    sommeProduitCarrefour = 0
    price_list_leclerc = []
    price_list_carrefour = []
    mergeCSV(fichierCarrefour, fichierLeclerc)
    for produit in panier:
        resultLeclerc = RechercheMinimum(fichierLeclerc, produit)       
        resultCarrefour = RechercheMinimum(fichierCarrefour, produit)
        price_list_leclerc.append(resultLeclerc)
        price_list_carrefour.append(resultCarrefour)
        sommeProduitLeclerc += resultLeclerc
        sommeProduitCarrefour += resultCarrefour
    
    Graph(price_list_carrefour, price_list_leclerc, panier)
    
    
     
    print('Votre panier coûte', round(sommeProduitLeclerc, 2) , '€ chez Leclerc')
    print('Votre panier coûte', round(sommeProduitCarrefour, 2), '€ chez Carrefour')
    print('\n')

    if sommeProduitLeclerc > sommeProduitCarrefour:
        print('On vous conseille de faire vos courses chez Carrefour')
        return ('Carrefour')
    
    elif sommeProduitCarrefour > sommeProduitLeclerc:
        print('On vous conseille de faire vos courses chez Leclerc')
        return ('Leclerc')
    
    else: 
        print('Le prix de votre panier est identique chez Leclerc et Carrefour')
        return ('Carrefour et Leclerc')

if __name__ == "__main__":
    
    CSV_Carrefour = pd.read_csv("Carrefour.csv")
    CSV_Leclerc = pd.read_csv("Leclerc.csv")
    panier =  SaisirPanier()
    Resultat = RecherchePanier(CSV_Leclerc, CSV_Carrefour, panier)  
