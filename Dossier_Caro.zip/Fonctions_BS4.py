# -*- coding: utf-8 -*-
"""
Created on Mon May 10 19:27:17 2021

@author: Antho
"""

from bs4 import BeautifulSoup
import requests
import time


def processString(txt):
    charSpe = txt.maketrans("âàéèëêïîçùô", "aaeeeeiicuo", "!#$%^&*()")
    txt = txt.translate(charSpe)
    return txt

def clean_type_list(type_list):
    new_list = []
    for word in type_list:
        text_clean = word.replace('_', ' ').replace(' surgeles','').replace(' desinfectantes','')
        new_list.append(text_clean)
    return new_list

def GetProduct(nameList, productList, priceList, type_list, Market_List):
     for name in nameList:
        url = 'https://www.carrefour.fr/s?q=%27' + str(name)
        reponse = requests.get(url)
        time.sleep(5)
        soup = BeautifulSoup(reponse.text, 'lxml')

        containers = soup.find_all('article')

        for each in containers:
            titre = each.find('h2').text.replace('\n','').lower().replace('°','')
            titre = processString(titre)
            productList.append(titre)
            type_list.append(name)
            Market_List.append('Carrefour')


        containers1 = soup.find_all('div', class_="product-card-price__price")

        for each1 in containers1:
            price = each1.span.text.replace(',', '.').replace('€', '').replace('/n','')
            priceList.append(float(price))

     return productList,priceList,type_list
 
