# -*- coding: utf-8 -*-
"""
Created on Mon May 10 19:24:13 2021

@author: Antho
"""


import pandas as pd
from Fonctions_BS4 import GetProduct, clean_type_list


def Carrefour(nameList):
    
    priceList = []
    productList=[]
    type_list = []
    Market_List=[]

    productList,priceList,type_list= GetProduct(nameList,productList,priceList,type_list,Market_List)
    type_list= clean_type_list(type_list)
    df = pd.DataFrame(list(zip(Market_List,type_list, productList, priceList)), columns = ['Market','Categorie', 'Products Name', 'Prices'])
    print(df)
    return df

def getCSV(df):
    df.to_csv('Carrefour.csv')

if __name__ == '__main__':

    nameList = ['masque_chirurgical','gel_hydroalcoolique','legumes_surgeles', 'farines', 'les_pates', 'lingettes_desinfectantes', 'papiers_toilette', 'laits', 'les_riz', 'liquides_vaisselles','eaux_plates','huiles']
    df = Carrefour(nameList)
    getCSV(df)
    