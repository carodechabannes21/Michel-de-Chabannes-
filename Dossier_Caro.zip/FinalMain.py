# -*- coding: utf-8 -*-
"""
Created on Mon May 10 20:40:17 2021

@author: Antho
"""
import pandas as pd
from Main_BS4 import Carrefour, getCSV
from Main_Selenium import Leclerc, df_to_csv
from Fonctions_Fusion import SaisirPanier, RecherchePanier

def Main():
    
    nameList_Carrefour = ['masque_chirurgical','gel_hydroalcoolique','legumes_surgeles', 'farines', 'les_pates', 'lingettes_desinfectantes', 'papiers_toilette', 'laits', 'les_riz', 'liquides_vaisselles','eaux_plates','huiles']
    df_Carrefour = Carrefour(nameList_Carrefour)
    getCSV(df_Carrefour)
    url = 'https://www.e.leclerc/'
    nameList_Leclerc = ['legumes-', 'farines-et-levures', 'les-pates', 'lingettes-et-plumeaux', 'papiers-toilette', 'laits', 'les-riz', 'liquides-vaisselles','eaux-plates', 'huiles']
    df_Leclerc = Leclerc(url, nameList_Leclerc)
    df_to_csv(df_Leclerc)
    CSV_Carrefour = pd.read_csv("Carrefour.csv")
    CSV_Leclerc = pd.read_csv("Leclerc.csv")
    panier =  SaisirPanier()
    RecherchePanier(CSV_Leclerc, CSV_Carrefour, panier)
    
    
if __name__ == "__main__": 
    
    
    Main()
    
    