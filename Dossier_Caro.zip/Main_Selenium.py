# -*- coding: utf-8 -*-
"""
Created on Fri May  7 15:47:38 2021

@author: Antho
"""

from time import sleep
from Fonctions_Get import get_masques_gel, get_name_price_list
from Fonctions_Clean import clean_masques_gel, clean_price, clean_list_name, clean_type_List_All, float_price
from Fonctions_Divers import accept_leclerc_terms, search, dict_to_df
#from Fonctions_Fusion import mergeCSV

def get_driver():
    print("create driver chrome")
    from selenium import webdriver
    return webdriver.Chrome()
    
def Leclerc(url, nameList):
    driver = get_driver()
    driver.get(url)
    sleep(8)
    accept_leclerc_terms(driver)
    sleep(5)
    search(driver)
    sleep(5)
    #On scrappe gel hydroalcoolique et masques
    market_list_gel_masques, type_list_gel_masques, masques_gel_name, masques_gel_price = get_masques_gel(driver)
    sleep(2)
    masques_gel_name, masques_gel_price, type_list_gel_masques, market_list_gel_masques = clean_masques_gel(masques_gel_name, masques_gel_price, type_list_gel_masques, market_list_gel_masques)
    sleep(2)
    #On scrappe tous les autres éléments
    market_List, type_List, product_List, price_List = get_name_price_list(driver, nameList)
    sleep(2)
    price_List = clean_price(price_List)
    
    #On assemble les listes Gel/Masque avec les autres éléments
    type_List_All = type_list_gel_masques + type_List
    
    type_List_All = clean_type_List_All(type_List_All) #Catégorie Clean
    
    #On assemble toutes les listes Gel/Masque avec les autres éléments
    market_List_All = market_list_gel_masques + market_List
    New_Product_List = masques_gel_name + product_List
    New_Price_List = masques_gel_price + price_List
    
    #On convertit les prix chaine de caractère --> float
    New_Price_List = float_price(New_Price_List)
    
    New_Product_List_clean = clean_list_name(New_Product_List)
    
    df = dict_to_df(New_Product_List_clean, New_Price_List, market_List_All, type_List_All)
    
    driver.close()
    return df

def df_to_csv(df):
    df.to_csv("Leclerc.csv")     
    
    
if __name__ == '__main__':
    url = 'https://www.e.leclerc/'
    nameList = ['legumes-', 'farines-et-levures', 'les-pates', 'lingettes-et-plumeaux', 'papiers-toilette', 'laits', 'les-riz', 'liquides-vaisselles','eaux-plates', 'huiles']
    df = Leclerc(url, nameList)
    df_to_csv(df)
    